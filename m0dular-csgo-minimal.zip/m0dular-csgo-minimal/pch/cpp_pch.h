#include <vector>
#include <atomic>
#include <boost/interprocess/containers/vector.hpp>
#include <boost/unordered_map.hpp>
#include "sdk/source_csgo/sdk.h"
#include "sdk/framework/math/mmath.h"
#include "sdk/framework/utils/packed_heap.h"
#include "sdk/framework/utils/vfhook.h"
