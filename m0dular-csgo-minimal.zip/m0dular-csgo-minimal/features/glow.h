#ifndef GLOW_H
#define GLOW_H

namespace Glow
{
	void Run();
	void Shutdown();
}

#endif