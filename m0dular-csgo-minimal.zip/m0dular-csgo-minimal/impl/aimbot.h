#ifndef AIMBOT_IMPL_H
#define AIMBOT_IMPL_H

namespace AimbotImpl
{
	extern int minDamage;
	extern float maxFOV;

}

#endif
