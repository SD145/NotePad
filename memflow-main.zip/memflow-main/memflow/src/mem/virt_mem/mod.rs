pub mod virtual_dma;

#[doc(hidden)]
pub use virtual_dma::VirtualDma;
